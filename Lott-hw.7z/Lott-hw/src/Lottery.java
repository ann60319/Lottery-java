import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.*;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.util.Timer;
import java.util.TimerTask;

import javafx.scene.control.Button;

import java.awt.Dimension;
import javax.swing.JSplitPane;
import javax.swing.JToolBar;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.Frame;

import javax.swing.ImageIcon;
import java.awt.Color;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.SwingConstants;
import java.awt.Component;
import java.awt.Container;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.SystemColor;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.Panel;
import java.awt.GridLayout;

public class Lottery extends JFrame {

	private static JPanel contentPane;
	private static JLabel lbl1nd_sign_1,lblwin_num_1,lblmatch;
	private static JButton btnsystem_getnum,btnclear,btnset,btnmatch;
	private static JPanel panel_1= new JPanel(new GridLayout(10,200));
	
	//class- Arraylist
	private static List<JButton> numJButton = new ArrayList<>();//save all auto generate numbtn 
	private static List<String> tmpselectnum = new ArrayList<>();//tmp save what num we choose 
	private static List<JButton> selectbtn= new ArrayList<>();//collect num btn we choose 
	private static List<Integer> collectnum = new ArrayList<>();//system generate rnd collect num to sort
	private static List<Integer> matched = new ArrayList<>();//the number matched to win num
	private static List<Integer> winnum = new ArrayList<>();//the official number generate for lottery winner
	//class parameter
	private static final int collect = 6;//the lottery limit only choose 6 numbers once
	
	//class string
	private static String num;
	
	
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					Lottery frame = new Lottery();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
		
		
		
		
		
	}//main end

	/**
	 * Create the frame.
	 */
	public Lottery() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 584, 603);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(255, 248, 220));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(6, 372, 572, 203);
		panel.setPreferredSize(new Dimension(10, 180));
		panel.setBackground(new Color(240, 128, 128));
		contentPane.add(panel);
		GridBagLayout gbl_panel = new GridBagLayout();
		gbl_panel.columnWidths = new int[]{152, 213, 72, 0, 0, 0};
		gbl_panel.rowHeights = new int[]{0, 42, 49, 48, 0};
		gbl_panel.columnWeights = new double[]{0.0, 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		gbl_panel.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE};
		panel.setLayout(gbl_panel);
		
		btnsystem_getnum = new JButton("�q���︹");
		btnsystem_getnum.setOpaque(true);
		btnsystem_getnum.setBorder(null);
		btnsystem_getnum.setForeground(new Color(0, 0, 0));
		btnsystem_getnum.setBackground(Color.blue);
		btnsystem_getnum.setRolloverIcon(new ImageIcon(Lottery.class.getResource("/source/select.png")));
		btnsystem_getnum.setIcon(new ImageIcon(Lottery.class.getResource("/source/select (1).png")));
		btnsystem_getnum.setFont(new Font("Dialog", Font.PLAIN, 16));
		GridBagConstraints gbc_btnsystem_getnum = new GridBagConstraints();
		gbc_btnsystem_getnum.insets = new Insets(0, 0, 5, 5);
		gbc_btnsystem_getnum.gridx = 1;
		gbc_btnsystem_getnum.gridy = 0;
		panel.add(btnsystem_getnum, gbc_btnsystem_getnum);
		
		btnclear = new JButton("�M��/����");
		btnclear.setBackground(Color.BLUE);
		btnclear.setOpaque(true);
		btnclear.setIcon(new ImageIcon(Lottery.class.getResource("/source/replay.png")));
		btnclear.setRolloverIcon(new ImageIcon(Lottery.class.getResource("/source/replay (1).png")));
		btnclear.setFont(new Font("Dialog", Font.PLAIN, 16));
		GridBagConstraints gbc_btnclear = new GridBagConstraints();
		gbc_btnclear.insets = new Insets(0, 0, 5, 5);
		gbc_btnclear.gridx = 2;
		gbc_btnclear.gridy = 0;
		panel.add(btnclear, gbc_btnclear);
		
		btnmatch = new JButton("�I��");
		btnmatch.setOpaque(true);
		btnmatch.setBackground(Color.blue);
		btnmatch.setRolloverIcon(new ImageIcon(Lottery.class.getResource("/source/lottery (2).png")));
		btnmatch.setIcon(new ImageIcon(Lottery.class.getResource("/source/lottery (1) ����.png")));
		btnmatch.setFont(new Font("Dialog", Font.PLAIN, 16));
		
		GridBagConstraints gbc_btnmatch = new GridBagConstraints();
		gbc_btnmatch.insets = new Insets(0, 0, 5, 5);
		gbc_btnmatch.gridx = 3;
		gbc_btnmatch.gridy = 0;
		panel.add(btnmatch, gbc_btnmatch);
		
		JLabel lblwinnum = new JLabel("�}�����X");
		lblwinnum.setIcon(new ImageIcon(Lottery.class.getResource("/source/lottery (3).png")));
		lblwinnum.setPreferredSize(new Dimension(78, 50));
		lblwinnum.setMaximumSize(new Dimension(78, 50));
		lblwinnum.setFont(new Font("Dialog", Font.PLAIN, 16));
		GridBagConstraints gbc_lblwinnum = new GridBagConstraints();
		gbc_lblwinnum.insets = new Insets(0, 0, 5, 5);
		gbc_lblwinnum.gridx = 0;
		gbc_lblwinnum.gridy = 1;
		panel.add(lblwinnum, gbc_lblwinnum);
		
		lblwin_num_1 = new JLabel("");
		lblwin_num_1.setFont(new Font("Helvetica", Font.BOLD, 18));
		GridBagConstraints gbc_lblwin_num_1 = new GridBagConstraints();
		gbc_lblwin_num_1.insets = new Insets(0, 0, 5, 5);
		gbc_lblwin_num_1.gridx = 1;
		gbc_lblwin_num_1.gridy = 1;
		panel.add(lblwin_num_1, gbc_lblwin_num_1);
		
		JLabel lbl1st = new JLabel("�U�`���X");
		lbl1st.setIcon(new ImageIcon(Lottery.class.getResource("/source/menu (1).png")));
		lbl1st.setFont(new Font("Dialog", Font.PLAIN, 16));
		GridBagConstraints gbc_lbl1st = new GridBagConstraints();
		gbc_lbl1st.insets = new Insets(0, 0, 5, 5);
		gbc_lbl1st.gridx = 0;
		gbc_lbl1st.gridy = 2;
		panel.add(lbl1st, gbc_lbl1st);
		
		lbl1nd_sign_1 = new JLabel("");
		lbl1nd_sign_1.setFont(new Font("Helvetica", Font.BOLD, 18));
		GridBagConstraints gbc_lbl1nd_sign_1 = new GridBagConstraints();
		gbc_lbl1nd_sign_1.insets = new Insets(0, 0, 5, 5);
		gbc_lbl1nd_sign_1.gridx = 1;
		gbc_lbl1nd_sign_1.gridy = 2;
		panel.add(lbl1nd_sign_1, gbc_lbl1nd_sign_1);
		
		JLabel label = new JLabel("�������X");
		label.setIcon(new ImageIcon(Lottery.class.getResource("/source/prize-winner.png")));
		label.setFont(new Font("Dialog", Font.PLAIN, 16));
		GridBagConstraints gbc_label = new GridBagConstraints();
		gbc_label.insets = new Insets(0, 0, 0, 5);
		gbc_label.gridx = 0;
		gbc_label.gridy = 3;
		panel.add(label, gbc_label);
		
		lblmatch = new JLabel("");
		lblmatch.setFont(new Font("Helvetica", Font.BOLD, 18));
		GridBagConstraints gbc_lblmatch = new GridBagConstraints();
		gbc_lblmatch.insets = new Insets(0, 0, 0, 5);
		gbc_lblmatch.gridx = 1;
		gbc_lblmatch.gridy = 3;
		panel.add(lblmatch, gbc_lblmatch);
		
		//add all btn actionlistner
		btnclear.addActionListener(new ActLis());
		btnsystem_getnum.addActionListener(new ActLis());
		btnmatch.addActionListener(new ActLis());
		
		createbtn(7,7);
		
		
	}


static void createbtn(int n1, int n2) 
{
	int btnName=1;
	int btnTxt=1;
	for(int i=0;i<n1;i++) 
	{
		for(int k=0;k<n2;k++) 
		{
			JButton numbtn=new JButton();
			numbtn.setName(String.valueOf(btnName++));
			numbtn.setText(String.valueOf(btnTxt++));
			numbtn.setBorder(new CompoundBorder(new BevelBorder(BevelBorder.RAISED, null, null, null, null),
					new EmptyBorder(10, 10, 10, 10)));
			numbtn.setBounds(30+65*k, 30+45*i, 65, 45);
			numbtn.setFont(new Font("Helvetica", Font.BOLD, 16));
			numbtn.setForeground(Color.BLACK);
			numbtn.setBackground(new Color(255,104,100));
			numbtn.setOpaque(true);
			contentPane.add(numbtn);
			numbtn.addActionListener(new ActLis());
			numJButton.add(numbtn);
		}
	}
	
}//static void createbtn ---end

static class ActLis implements ActionListener
{
	@Override
	public void actionPerformed(ActionEvent e) 
	{
		JButton jbutton=(JButton)e.getSource();
		
		for(int i=1;i< numJButton.size();i++) 
		{
			if(jbutton.equals(numJButton.get(i))) 
			{
				try 
				{
					output_num(numJButton.get(i));
				} catch (Exception e1) 
				{
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				
			}
		}
		
		if(jbutton.equals(btnclear)) 
		{
			//System.out.println("click clear");
			tmpselectnum.clear();
			selectbtn.clear();
			collectnum.clear();
			num="";
			lbl1nd_sign_1.setText(num);
			//System.out.println("num");
			lblwin_num_1.setText(num);
			lblmatch.setText(num);
			
			for(JButton jb:numJButton) 
			{
				jb.setBackground(new Color(255,104,100));
			}
			btnmatch.setEnabled(true);
			btnsystem_getnum.setEnabled(true);
			
		}
		
		else if(jbutton.equals(btnsystem_getnum)) 
		{
			//System.out.println("click rnd");
			if(collectnum.size()<6) 
			{
				//btnclear.setEnabled(false);
				
				
				flash();
				ranNum();
				
				new Thread() {
					public void run() {
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						ranNum();
						num="";
						for(Integer i:collectnum) 
						{
							num+=i+" ";
							numJButton.get(i-1).setBackground(new Color(255,255,179));
							//System.out.println(collectnum.indexOf(i));
						}
						lbl1nd_sign_1.setText(num);
					}
					
				}.start();
			}
			else 
			{
				JOptionPane.showMessageDialog(null, "You already choose 6 numbers,plz click clear to reset and get rnd numbers", "Attention", JOptionPane.WARNING_MESSAGE);
			}
			//System.out.println(collectnum.get(1)+"----get 1-------");
		}
		
		else if(jbutton.equals(btnmatch)) 
		{
			if(collectnum.size()==6) 
			{
				
				//flash1();
				match(collectnum);
				btnsystem_getnum.setEnabled(false);
				btnmatch.setEnabled(false);
			}
			else 
			{
				JOptionPane.showMessageDialog(null, "You Haven't Choose Six Number !", "Attention!!",
						JOptionPane.WARNING_MESSAGE);
			}
		}
		
	}

}// static class ActLis implements ActionListener----end

 public static void output_num(JButton jButton) throws Exception
{
	boolean l=tmpselectnum.contains(jButton.getText());
	
	if(tmpselectnum.size()<collect) 
	{
		if(l==true) 
		{
			jButton.setBackground(new Color(255,104,100));
			tmpselectnum.remove(tmpselectnum.indexOf(jButton.getText()));
			selectbtn.remove(selectbtn.indexOf(jButton));
			num = "";
			lbl1nd_sign_1.setText(num);
			for(String str:tmpselectnum) 
			{
				num+=str+" ";
			}
			lbl1nd_sign_1.setText(num);
			
		}
		else 
		{
			
			num="";
			tmpselectnum.add(jButton.getText());
			int k=Integer.parseInt(jButton.getText());
			collectnum.add(k);
			selectbtn.add(jButton);
			jButton.setBackground(new Color(255,255,179));	
			//System.out.println(tmpselectnum);
			
			for(String str:tmpselectnum) 
			{
				num+=str+" ";
			}
			lbl1nd_sign_1.setText(num);
			
		}
	}
	else 
	{
		JOptionPane.showMessageDialog(null,"�A�w�g��W�L���ӧ�`���X�o��","Attention",JOptionPane.WARNING_MESSAGE);
	}
}

 
 
static void ranNum() 
{
	int num=collect-tmpselectnum.size(),collect;
	boolean bool;
	String strnum="";
	
	for(int i=0; i<num;i++) 
	{
		strnum=Integer.toString((int)(Math.random()*49+1));
		bool=tmpselectnum.contains(strnum);
		
		if (bool==true) 
		{
			i--;
		}
		else 
		{
			tmpselectnum.add(strnum);
			//System.out.println(strnum);
			collect=Integer.parseInt(strnum);
			collectnum.add(collect);
			
		}
		Collections.sort(collectnum);
		
		
	}
	
}

static void flash() {
	Timer t=new Timer();
	TimerTask show=new TimerTask() {
		public void run() 
		{
			for(int i=0;i<100;i++) 
			{
				int num=(int)(Math.random()*49);
				numJButton.get(num).setBackground(new Color(255,255,179));
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				numJButton.get(num).setBackground(new Color(255,104,100));
			}
			for(JButton btn:numJButton) 
			{
				for(Integer i:collectnum) 
				{
					String ll=i.toString();
					if(btn.getText().equals(ll)) 
						{
							btn.setBackground(new Color(255,255,179));
							
						}
					
					
				}
			}
		}
	};
	
	t.schedule(show, 0);
}

static void flash1() {
	Timer t=new Timer();
	TimerTask show=new TimerTask() {
		public void run() 
		{
			for(int i=0;i<100;i++) 
			{
				int num=(int)(Math.random()*49);
				numJButton.get(num).setBackground(new Color(128,212,255));
				try {
					Thread.sleep(10);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				numJButton.get(num).setBackground(new Color(255,104,100));
			}
			for(JButton btn:numJButton) 
			{
				for(Integer i:winnum) 
				{
					//String ll=i.toString();
					boolean bool=winnum.contains(collectnum.get(i));
					if(bool==false) 
						{
							btn.setBackground(new Color(255,255,179));
							
						}
					/*else if (bool==false){
						btn.setBackground(new Color(0,136,204));
					}*/
					
				}
			}
		}
	};
	
	t.schedule(show, 0);
}


static void match(List<Integer> intlist) 
{
	boolean bool1,bool2;
	int ran;
	String str="",str2="";
	
	//generate ran num
	lblwin_num_1.setText(str);
	winnum.clear();
	matched.clear();
	for(int i=0;i<collect;i++) 
	{
		ran=(int)(Math.random()*49+1);
		bool1=winnum.contains(ran);
		if(bool1==true) {
			i--;
		}
		else {
			winnum.add(ran);
		}
		
	}
	Collections.sort(winnum);
	for(Integer l:winnum) {
		str+=l+" ";
	}
	lblwin_num_1.setText(str);
	
	//matching process
	for(int i=0;i<collect;i++) 
	{
		bool2=winnum.contains(collectnum.get(i));
		
		if(bool2==true) 
		{
			matched.add(collectnum.get(i));
		}
	}
	Collections.sort(matched);
	for(Integer l:matched) {
		str2+=l+" ";
	}
	lblmatch.setText(str2);
	
	switch(matched.size()) 
	{
		case 6:
			JOptionPane.showMessageDialog(null, "���ߧA���Y���F�I�I�I������@���y��");
		break;	
		
		case 5:
			JOptionPane.showMessageDialog(null, "���ߧA��5�Ӹ��X");
		break;
	
		case 4:
			JOptionPane.showMessageDialog(null, "���ߧA��4�Ӹ��X");
		break;
		
		case 3:
			JOptionPane.showMessageDialog(null, "���ߤ�3�Ӹ��X");
		break;
		
		case 2:
			JOptionPane.showMessageDialog(null, "���ߧA��2�Ӹ��X");
		break;
		
		case 1:
			JOptionPane.showMessageDialog(null, "���ߧA��1�Ӹ��X");
		break;
		
		default:
			break;
	}
	
}

}//public lottery ---end














