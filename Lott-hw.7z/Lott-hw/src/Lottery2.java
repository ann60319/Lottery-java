import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Panel;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class Lottery2 extends JFrame {

	private JPanel contentPane;
	private static Frame frm=new Frame("大樂透兌獎系統");
    private static Panel pn1=new Panel(new GridLayout(4,3));
    private static Button digits[]=new Button[10];
    private static long num;//存放結果


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) 
	{
		EventQueue.invokeLater(new Runnable() 
		{
			public void run() 
			{
				try 
				{
					Lottery2 frame = new Lottery2();
					frame.setVisible(true);
				} 
				catch (Exception e) 
				{
					e.printStackTrace();
				}
			}
		});
		 for(int i=1;i<50;i++)
		 	{
		        digits[i]=new Button(Integer.toString(i));
		        pn1.add(digits[i]);
		        //digits[i].addActionListener(new ActLis());
		    }
	}

	/**
	 * Create the frame.
	 */
	public Lottery2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
	}

}
